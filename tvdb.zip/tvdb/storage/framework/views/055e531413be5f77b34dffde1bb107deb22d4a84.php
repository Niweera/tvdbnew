<?php $__env->startSection('content'); ?>
    <h1 class="text-center mt-3" style="text-shadow: 0 1px 3px rgba(0,0,0,.5);color:white">Update TV Series Data</h1>
    <div class="jumbotron">
        <?php echo Form::open(['action' => ['TVSeriesController@update',$posts->tvid], 'method' => 'POST', 'class' => 'mb-4']); ?>

            <div class = "form-group">
                <?php echo e(Form::label('tvname','TV Name*')); ?>

                <?php echo e(Form::text('tvname', $posts->tvname, ['class' => 'form-control', 'placeholder' => 'Enter TV Name'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('showtype','Show Type*')); ?>

                <?php echo e(Form::select('showtype', ['Airing' => 'Airing', 'Break' => 'Break', 'Completed' => 'Completed'], $posts->showtype,['class' => 'form-control'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('remarks','Remarks')); ?>

                <?php echo e(Form::text('remarks', $posts->remarks, ['class' => 'form-control', 'placeholder' => 'Enter Remarks'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('link','Link')); ?>

                <?php echo e(Form::text('link', $link, ['class' => 'form-control', 'placeholder' => 'Enter Wikipedia Link'])); ?>

            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::label('pid','Place')); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::label('tvfrom','TV From')); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::label('tvto','TV To')); ?>

                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class = "form-group">
                            <?php echo e(Form::text('place'.$loop->index, $place->pid, ['class' => 'form-control', 'placeholder' => 'Enter Place','disabled'])); ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class = "form-group">
                            <?php echo e(Form::text('tvfrom'.$loop->index, $place->tvfrom, ['class' => 'form-control', 'placeholder' => 'Enter TV From'])); ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class = "form-group">
                            <?php echo e(Form::text('tvto'.$loop->index, $place->tvto, ['class' => 'form-control', 'placeholder' => 'Enter TV To'])); ?>

                        </div>
                    </div>
                </div>
                <?php echo e(Form::hidden('pid'.$loop->index, $place->pid)); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e(Form::hidden('_method',"PUT")); ?>

            <?php echo e(Form::hidden('loopcount', $count)); ?>

            <?php echo e(Form::submit('Update', ['class' => 'btn btn-dark'])); ?>


        <?php echo Form::close(); ?>


        <?php echo Form::open(['action' => ['TVSeriesController@store',$posts->tvid], 'method' => 'POST']); ?>

            <div class="row">
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::label('pid','Place')); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::label('tvfrom','TV From')); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::label('tvto','TV To')); ?>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::select('pid', ['b1' => 'b1', 'b2' => 'b2', 'b3' => 'b3', 'b4' => 'b4', 'b5' => 'b5', 'l' => 'l', 'p' => 'p'], 'l',['class' => 'form-control'])); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::text('tvfrom', '', ['class' => 'form-control', 'placeholder' => 'Enter TV From'])); ?>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class = "form-group">
                        <?php echo e(Form::text('tvto', '', ['class' => 'form-control', 'placeholder' => 'Enter TV To'])); ?>

                    </div>
                </div>
            </div>
            <?php echo e(Form::hidden('hiddentvid', $posts->tvid)); ?>

            <?php echo e(Form::submit('Insert New Place', ['class' => 'btn btn-dark', 'name' => 'btnSubmit'])); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>