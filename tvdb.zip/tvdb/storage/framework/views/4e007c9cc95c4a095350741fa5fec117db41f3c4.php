<?php $__env->startSection('content'); ?>
    <h1 class="text-center mt-3" style="text-shadow: 0 1px 3px rgba(0,0,0,.5);color:white">Insert TV Series Data</h1>
    <div class="jumbotron">
        <?php echo Form::open(['action' => 'TVSeriesController@store', 'method' => 'POST']); ?>

            <div class = "form-group">
                <?php echo e(Form::label('tvname','TV Name*')); ?>

                <?php echo e(Form::text('tvname', '', ['class' => 'form-control', 'placeholder' => 'Enter TV Name'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('showtype','Show Type*')); ?>

                <?php echo e(Form::select('showtype', ['Airing' => 'Airing', 'Break' => 'Break', 'Completed' => 'Completed'], 'Airing',['class' => 'form-control'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('remarks','Remarks')); ?>

                <?php echo e(Form::text('remarks', '', ['class' => 'form-control', 'placeholder' => 'Enter Remarks'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('link','Link')); ?>

                <?php echo e(Form::text('link', '', ['class' => 'form-control', 'placeholder' => 'Enter Wikipedia Link'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('pid','Place')); ?>

                <?php echo e(Form::select('pid', ['b1' => 'b1', 'b2' => 'b2', 'b3' => 'b3', 'b4' => 'b4', 'b5' => 'b5', 'l' => 'l', 'p' => 'p'], 'l',['class' => 'form-control'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('tvfrom','TV From')); ?>

                <?php echo e(Form::text('tvfrom', '', ['class' => 'form-control', 'placeholder' => 'Enter TV From'])); ?>

            </div>
            <div class = "form-group">
                <?php echo e(Form::label('tvto','TV To')); ?>

                <?php echo e(Form::text('tvto', '', ['class' => 'form-control', 'placeholder' => 'Enter TV To'])); ?>

            </div>
            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-dark', 'name' => 'btnSubmit'])); ?>


        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>