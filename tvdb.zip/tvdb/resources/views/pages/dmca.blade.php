@extends('layouts.app')

@section('content')
  <div class="container mt-5">
    <h1 class="text-center" style="text-shadow: 0 1px 3px rgba(0,0,0,.5);color:white">Niweera TVDB DMCA Policy</h1>
  </div>
  <div class="jumbotron mt-5" style="background-color: #3b3a30;text-shadow: 0 1px 3px rgba(0,0,0,.5);color:white">
    <p class="font-weight-bold text-center h2">
      Niwder.me or/and Niweera TVDB is/are not for commercial use and it is for private use only. No Digital Media Content (here on TV series) is hosted on the server, All the links are affiliated with Wikipedia and only for educational purposes. Niwder.me or Niweera TVDB does not accept any responsibility for TV series hosted on third party sites and does not have any involvement in the downloading/uploading of such TV series. All data, information hosted on this website is only for educational purposes.
        </p>
  </div>
@endsection